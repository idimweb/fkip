# app_notulen
Aplikasi Notule untuk pencatatan data rapat aplikasi ini di buat menggunakan codeigniter 3 dengan ektensi database mysqli 
silahkan di download dan di kembangkan lagi untuk keperluan pembelajaran 

<hr /> 
<img src="https://lh3.googleusercontent.com/proxy/Q4rKqX1ndn7N64tLDabU1Id8IatanxYxE8KfEormifNYoe5OlL_O6d2J2f5hQl5mBxbxcgGjs72WYAgzqmNBEGapLznYE2tBjWJXiu5oMo7lO1LtBF3eoly-afOXgNtQZqa26sVfku71JTFZzA35pYiscsvOgFZUIZT7pUoThAnt9nGz6SKdOj5YMIBTPTT0Eo2DC38Q3Q73xVlcQr7chgP0jrMsDA">
  
<br /> 
<img src="https://storage.googleapis.com/pintaar-web.appspot.com/course-photo/1_mNEec5EuSpx7WCUVJcUtsw.jpeg">
