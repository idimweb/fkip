<?php
    $config['cacheable']    = true; //boolean, the default is true
	$config['cachedir']     = './assets/'; //string, the default is application/cache/
	$config['errorlog']     = './assets/'; //string, the default is application/logs/
	$config['imagedir']     = './assets/img/'; //direktori penyimpanan qr code
	$config['quality']      = true; //boolean, the default is true
	$config['size']         = '1024'; //interger, the default is 1024
	$config['black']        = array(224,255,255); // array, default is array(255,255,255)
	$config['white']        = array(70,130,180); // array, default is array(0,0,0)
