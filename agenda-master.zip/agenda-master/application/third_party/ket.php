<?php 
/**/
 $setting = array('setting','Bagian ini berfungsi untuk mengajukan data arsip yang kurang atau mungkin perlu untuk di data oleh ulang oleh bagian administrasi',
                  'keterangan_detail','Detail informasi pengajuan arsip saat ini : <b><i class="fa fa-share fa-spin"></i> pending</b>'); 

